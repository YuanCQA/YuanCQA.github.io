using UnityEngine;

public enum BlockState { Stand, LieX, LieZ }

[RequireComponent(typeof(BoxCollider))]
public class BlockShape : MonoBehaviour
{
    public Vector3Int size = new Vector3Int(1, 2, 1);
    public BlockState currentState = BlockState.Stand;

    public void SetSizeAndState(Vector3Int s, BlockState state)
    {
        size = s;
        currentState = state;
        UpdateCollider();
    }

    public BlockState CurrentState => currentState;

    private void UpdateCollider()
    {
        var col = GetComponent<BoxCollider>();
        if (col != null)
        {
            col.size = size;
            col.center = new Vector3(0, size.y / 2f, 0);
        }
    }

    private void OnValidate()
    {
        UpdateCollider();
    }
}