using UnityEngine;
using System.Collections;

[RequireComponent(typeof(BlockShape))]
public class ROLLBlockController : MonoBehaviour
{
    public float rollSpeed = 5f;
    private bool isRolling = false;
    private BlockShape shape;

    private void Start()
    {
        shape = GetComponent<BlockShape>();
    }

    public void TryMove(Vector3 dir)
    {
        if (!isRolling)
            StartCoroutine(Roll(dir));
    }

    IEnumerator Roll(Vector3 dir)
    {
        isRolling = true;

        Vector3 anchor = GetAnchor(dir);
        Vector3 axis = Vector3.Cross(Vector3.up, dir);

        for (int i = 0; i < 90; i++)
        {
            transform.RotateAround(anchor, axis, rollSpeed);
            yield return null;
        }

        SnapToGrid();
        UpdateState(dir);
        CheckForHole();
        isRolling = false;
    }

    Vector3 GetAnchor(Vector3 direction)
    {
        Vector3 offset = Vector3.zero;

        if (shape.CurrentState == BlockState.Stand)
        {
            offset = direction * 0.5f;
        }
        else if (shape.CurrentState == BlockState.LieX)
        {
            if (Mathf.Abs(direction.x) > 0)
                offset = direction * 1f;
            else
                offset = direction * 0.5f;
        }
        else if (shape.CurrentState == BlockState.LieZ)
        {
            if (Mathf.Abs(direction.z) > 0)
                offset = direction * 1f;
            else
                offset = direction * 0.5f;
        }

        return transform.position + offset + Vector3.down * (shape.size.y / 2f);
    }

    void SnapToGrid()
    {
        Vector3 pos = transform.position;

        pos.x = Mathf.Round(pos.x);
        pos.z = Mathf.Round(pos.z);

        float height = Mathf.Max(shape.size.x, shape.size.y, shape.size.z);
        float yOffset = GetYOffset();

        pos.y = yOffset;
        transform.position = pos;

        transform.rotation = Quaternion.Euler(
            Mathf.Round(transform.rotation.eulerAngles.x / 90f) * 90f,
            Mathf.Round(transform.rotation.eulerAngles.y / 90f) * 90f,
            Mathf.Round(transform.rotation.eulerAngles.z / 90f) * 90f
        );
    }

    float GetYOffset()
    {
        if (shape.CurrentState == BlockState.Stand)
            return shape.size.y / 2f;

        return shape.size.y / 2f;
    }

    void UpdateState(Vector3 dir)
    {
        if (shape.currentState == BlockState.Stand)
        {
            if (dir == Vector3.forward || dir == Vector3.back)
                shape.currentState = BlockState.LieZ;
            else
                shape.currentState = BlockState.LieX;
        }
        else if ((shape.currentState == BlockState.LieX && (dir == Vector3.left || dir == Vector3.right)) ||
                 (shape.currentState == BlockState.LieZ && (dir == Vector3.forward || dir == Vector3.back)))
        {
            shape.currentState = BlockState.Stand;
        }
        else
        {
            shape.currentState = (shape.currentState == BlockState.LieX) ? BlockState.LieZ : BlockState.LieX;
        }
    }

    void CheckForHole()
    {
        Vector3 halfExtents = new Vector3(shape.size.x, shape.size.y, shape.size.z) * 0.5f;
        Collider[] hits = Physics.OverlapBox(transform.position, halfExtents, transform.rotation);
        foreach (var hit in hits)
        {
            if (hit.CompareTag("GoalHole"))
            {
                var hole = hit.GetComponent<GoalHole>();
                if (hole != null && hole.Match(shape))
                {
                    Destroy(gameObject);
                    return;
                }
            }
        }
    }
}