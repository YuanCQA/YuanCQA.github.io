using UnityEngine;

public class InputManager : MonoBehaviour
{
    public ROLLBlockController block;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.W))
            block.TryMove(Vector3.forward);
        if (Input.GetKeyDown(KeyCode.S))
            block.TryMove(Vector3.back);
        if (Input.GetKeyDown(KeyCode.A))
            block.TryMove(Vector3.left);
        if (Input.GetKeyDown(KeyCode.D))
            block.TryMove(Vector3.right);
    }
}