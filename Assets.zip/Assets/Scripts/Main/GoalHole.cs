using UnityEngine;

public class GoalHole : MonoBehaviour
{
    public Vector3Int expectedSize;

    public bool Match(BlockShape shape)
    {
        return shape.size == expectedSize;
    }
}